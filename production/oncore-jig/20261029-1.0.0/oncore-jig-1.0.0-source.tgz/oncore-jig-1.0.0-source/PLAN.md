# oncore-emulator

Rev 1.0.0, not yet built: a modern u-blox timing receiver behind a
small microcontroller that speaks the Motorola Oncore binary protocol,
as a drop-in replacement for the GPS engine inside HP / Symmetricom
SmartClock receivers (58503A, Z3801A, Z3805A and kin) that take the
Oncore with a right-angle antenna jack.  Hosts that plug a straight
jack into the motherboard (Z3816A, KS-24361) are not drop-in.

The firmware study these references point to is in
[smartclockmon](https://github.com/charlieh0tel/smartclockmon).

## Why

- **Sensitivity.**  Much greater than the Oncore's.  A current module
  with an amplified antenna may hold satellites where an Oncore on
  the same feed does not.
- **Rejection and selectivity.**  Possibly better against
  interference and out-of-band signals; not measured.
- **Channels.**  Many more than the Oncore's eight.  The firmware
  still sees only as many as its 8-channel messages carry.
- **Constellations.**  More than GPS alone, in some cases (see
  Choosing the module).
- **1 PPS quantization.**  Likely finer-grained.  The Oncore's 1 PPS
  carries a deterministic error from "the granularity of the clock
  generating the 1PPS signal", which the receiver reports as the
  negative sawtooth so a user can remove it (VP Oncore Command
  Reference, Time RAIM).  No SmartClock image applies it: the only
  reader of the field is the Time RAIM page (smartclockmon
  `docs/firmware/README.md`).  So all of it enters the measured
  interval, the white phase noise the stability curves show out to
  about 500 s on a 58503A (`docs/stability.md`).  Motorola gives the
  VP and UT+ under 50 ns 1σ in position hold; Synergy Systems gives
  its u-blox based replacement under 25 ns (tech note #484-D).
- **Antenna current.**  The bias, 5 V as the Oncore's or 3 V (JP1),
  goes through the LEA-M8T's V_ANT: under 50 mA, 100 mA absolute
  maximum, cut on a short (LEA-M8T data sheet).  The UT+ notes allow an
  Oncore antenna 15 to 80 mA (`third_party/motorola/`).
- **Availability.**  The Oncore engines are long out of production.
- **Week rollover.**  The engines predate the 1999 and 2019
  rollovers, and one still in service reports a date 1024 weeks early
  (smartclockmon `docs/scpi/undocumented.md`,
  `:DIAGnostic:IDENtification:GPSystem`).  The images take the date
  from `@@Ba` and `@@Ea` as given and compare no week of their own
  (smartclockmon `docs/firmware/58503a-3704.md`, "Time Reset and the
  Oncore's time"), so the emulator sends the module's date, the true
  one.

## Shape

- **GNSS:** u-blox's LEA-M8T (others in Choosing the module).  It
  runs no user code; the firmware is u-blox's.
- **Translator:** an STM32C091FCP6 (Cortex-M0+, 256 KB flash, 36 KB
  RAM, TSSOP20) with two USARTs: UBX from the module, Oncore binary to
  the instrument.  Its TSSOP20 pinout is the STM32C011F6's for every
  pin the board uses (DS14720 against DS13866); the C091 bonds further
  ports to pins 1, 15, 19 and 20.  KiCad has no symbol for it, so the
  project library's `STM32C091FCPx` is the C011's with those four pins
  renamed.
- **1 PPS:** the module's time pulse straight to the instrument's 1 PPS
  pin through a 3.3 V to 5 V level shifter.  The microcontroller never
  touches the edge, so it adds no jitter.
- **USB:** the module's own USB port brought out, for the full
  protocol (UBX, NMEA, raw measurements) to gpsd or u-center, and for
  module firmware updates, with no translator code.  VDD_USB comes
  from VBUS through its own 3.3 V regulator, enabled by the module's
  3.3 V supply, as u-blox requires: the module's D+ pull-up shows only
  to a powered host, and only while the module is powered.
- **Flashing the STM32:** SWD on a Tag-Connect TC2030, and the ROM
  serial bootloader for `stm32flash` on a 6-pin FTDI TTL-232R-3V3
  header (USART1, not fitted; 3.3 V only, since the bootloader turns
  on PA10's pull-up, which the STM32 forbids above 4 V), with BOOT0
  held high by a solder jumper.  The pin counts only once option bit
  NBOOT_SEL is 0; the factory setting ignores it, and a blank part
  boots the bootloader anyway (AN5673).  No USB on the STM32.  A
  blank or bootloader-mode STM32 in the instrument listens on J1 pin 9
  (USART1 RX): a 0x7F in the instrument's stream starts the
  bootloader, which answers on pin 8.
- **Power:** 5 V from the Oncore socket, regulated to 3.3 V.  On the
  bench, D8, a Schottky from VBUS, powers the board from USB-C; it
  can only feed an instrument from USB, never the other way.  Nothing
  but the USB host limits that current (D8 is rated 1 A): use a
  computer's port, not a charger, when the board is in an instrument
  that is switched off.  On USB alone +5V is VBUS less D8's drop, about
  4.4 to 4.7 V, under U3 and U6's 4.5 V minimum on a weak port, so J1's
  output levels are not guaranteed on the bench.
- **Antenna bias:** 5 V as the Oncore supplied it, or 3 V from the
  module's VCC_RF by a solder jumper, through u-blox's 10 ohm R_bias,
  27 nH and 10 nF (LEA-M8T hardware integration manual, Figure 12).
  Once the firmware has saved UBX-CFG-ANT (TIM 1.1x ships with short
  detection off), the module switches V_ANT off when it sees a short,
  retries, and reports the antenna's state in UBX-MON-HW, which the
  STM32 reads; R_bias limits the current until it does, about 0.5 A
  at 5 V, so it is a 0.25 W or better anti-surge part as u-blox's
  parts list asks.  A TPS2553 current limit
  was dropped: its range stops above the module's 100 mA absolute
  maximum, the -1 latches off, and its fault flag, with a 7.5 ms
  deglitch, would rarely see a short the module has already cut.
- **Board:** the Oncore's outline, 82.55 x 50.80 mm, with its four
  3.2 mm holes 3.0 mm from the edges, and within its height: the
  Oncore's parts reach 7.18 mm above the board (UT+ notes; VP 7.35
  max), this board's about 3.2 mm (J3).  Below, the Oncore has its
  shield S2 (6.9 mm) and J1 (8.2 mm); this board has only J1 and J2
  (6 mm body).  J1's heights are in `docs/oncore-ten-pin.md`.  The holes are plated, with 5.0 mm pads (the most the edge
  allows), and float, as the Oncore's do (checked on one).  J1 sits at the Oncore's position
  and takes a 2x5 header on either side: on the bottom to plug in as
  the Oncore did, or on top for a ribbon jumper down to the
  motherboard.  Seen from above, both ends of a straight-through IDC
  ribbon then mate the same way, so pin n meets pin n.  Pin 1 is
  marked on both sides, with the header's outline on top.  J1 is
  wired as Motorola's table has it: pin 8 (TXD1) is the receiver's
  output and pin 9 (RXD1) its input.  Synergy's description column
  has pin 8 the other way (open question 3).  R25 holds the transmit line at idle while the STM32 is in
  reset, halted or blank.  The antenna is a right-angle
  through-hole MCX jack on the bottom, as on the Oncore, with its pin
  at the Oncore jack's position and its face at the left edge; MCX
  mates with the OSX plug on the instrument's cable.  USB-C sits on
  the same edge below it, and the FTDI header on the lower edge,
  backed off so its pins stay inside the outline.  In the instrument
  the board is buried under the power supply, so both are for the
  bench.
- **Layers:** four, 1.6 mm, on JLCPCB's standard JLC04161H-7628
  stackup.  Layer 2 is unbroken ground under the module and the RF
  trace, which makes the 50 ohm J2 to RF_IN run 0.36 mm wide (0.2104
  mm of 7628 prepreg, Er 4.4, less a little for solder mask) instead
  of about 2.9 mm on two layers, and leaves routing easy around the
  module.
- **Ordering:** `hardware/release.py` builds the package in
  `production/YYYYMMDD-REV/`, the jig's in
  `production/oncore-jig/YYYYMMDD-REV/` (see
  `.claude/skills/jlcpcb-release/`).
  JLC04161H-7628 with impedance control, since the RF
  trace's width assumes it; the board file records only the 1.6 mm
  thickness.  ENIG finish: the RF trace is bare copper.  J2 is the
  one through-hole part JLCPCB fits, on the bottom: confirm its
  bottom-side through-hole assembly when ordering.  JLCPCB has no model
  for J2: an order remark, in English and Chinese, says it goes on the
  bottom with its face out past the left edge, as the bottom silk shows
  (text in `.claude/skills/jlcpcb-release/SKILL.md`).  J2 and J3 overhang
  the left edge (x = 100): no rail or V-score on that edge.
- **Layout:** `hardware/schematic.py` drew the schematic and
  `hardware/board.py` made the outline, holes and placement from it.
  Both are retired: the schematic is edited and the board routed in
  KiCad, and schematic changes reach the board with Update PCB from
  Schematic.  TP2, a Keystone 5019 loop by J1 for a scope probe's
  ground clip, is not fitted.
- **Routing:** by hand in KiCad, every net connected.  Layer 2 is a
  GND plane and layer 3 a +3V3 plane, with GND pours on top and
  bottom; all four zones are drawn larger than the board and clipped
  by its outline.  GND and +3V3 pads reach their plane by a short
  N/S/E/W track to a via (two for pads 2.5 mm or longer), except U1's
  ground pins 13 and 14, which reach the top pour through its thermal
  spokes.  GND vias
  stitch the pours together 1 mm in from the edge every 3 mm (2 mm
  along the RF corner by J2, and on under J5's overhanging pins), and
  on a 5 mm grid inside, wherever both outer pours are solid copper
  and no part is in the way.  The RF trace is
  placed by hand and locked, keeps 3W (1.08 mm) to the pour and other
  nets, is fenced by ground vias along both sides, and has D7 on it
  beside J2.  It has no solder mask, except 0.4 mm dams either side of
  D7's pad and before U1 pin 16, so solder stays on those joints.  No other net's vias come within 0.4 mm of the module's
  pads.  Silkscreen text is 0.8 mm high with a 0.15 mm stroke.
- **Assembly:** JLCPCB, passives no smaller than 0603 except the RF
  input's ESD diode (PESD5V0F1BL, SOD-882: 0.4 pF, 5.5 V stand-off,
  above the 5 V antenna bias on RF_IN).  The schematic carries each
  part's manufacturer, part number and LCSC number, all in JLCPCB's
  stock on 2026-10-25 except J1 and the cell.  The LEA-M8T is JLCPCB's
  C2763452, a LEA-M8T-0 (TIM 1.10), of which JLCPCB had only 8: check
  the count before ordering.  JLCPCB places it with u-blox's T-shaped
  paste (integration manual Figure 6), so ask for the 150 um stencil.
  Why the -0 and not the -1 is in `docs/ublox-lea-m8t-version.md`.
  J4, JP1, JP2 and TP1 are footprints only, out of the BOM.  J1 is
  marked not fitted and the backup cell is not fitted: both are
  ordered loose and fitted by hand, J1 on whichever side the instrument
  needs.  J1 is a Samtec TSW-105-07-G-D (DigiKey), whose 5.84 mm mating
  length is the Oncore's; CJT's A2541WV-2x5P (LCSC C225520, 6.0 mm) is
  the LCSC alternative.  The connector's pinout, position and heights
  are in `docs/oncore-ten-pin.md`.  J5 and TP2 (the Keystone 5019, out
  of stock) are not fitted.  The STAT LED
  is yellow-green: a green's 3.1 V barely lights from 3.3 V.
- **Backup supply:** the module's V_BCKP tied to VCC by default.  The
  option not fitted is a Seiko MS621FE-FL11E rechargeable lithium cell
  (5.5 mAh, about 13 days at the module's 17 uA; rated -20 to +60 C,
  narrower than the module's -40 to +85 C), floated at about
  3.2 to 3.3 V through a BAT54J Schottky and 1k: at float current the
  Schottky drops only 0.1 to 0.15 V.  The cell wants 2.8 to 3.3 V,
  3.1 V recommended, so this is the top of its range; a silicon
  diode's 0.6 V would leave it at the bottom.  Its reverse leakage (2 uA maximum at 25 V,
  25 C) matters only while the board is unpowered, when the instrument
  has cooled and D3 sees about 3 V: a few percent of the module's
  backup current.  No SMD supercap comes close: the 0.22 F parts
  are end of life and the active ones hold minutes.  The
  cell is not reflowable (third_party/seiko/).  No known instrument
  drives the Oncore's BATT pin, so it is not used.

## What the translator does

- Answers, and sends, only the messages the target image expects.
  Nothing else goes on the wire, unsolicited or not.  smartclockmon
  `docs/firmware/oncore/models.md` lists them for the six Oncore
  images, and `<image>.txt` beside it gives each image's message
  table, request scripts and polling lists.
- Fills them from the module: time, satellites, position, receiver
  status; honors position hold, the survey, and cable delay; fills the
  T-RAIM fields.
- Presents a week number the firmware handles.
- Carries the module's own 1 PPS quantization error into the Oncore's
  sawtooth field.  The firmware displays it, which also shows whether
  anything applies it.

The firmware must also set the hardware up, since the module's and
the MCU's defaults are not the Oncore's:

- **1 PPS** goes from the module to J1 without passing through the
  MCU, so its shape is the module's.  UBX-CFG-TP5 sets it to the
  Oncore's: a 200 ms (+/-1 ms) rising-edge pulse from power-up, not
  the TIM default of 100 ms only once locked; antenna cable delay 0
  (the default is 50 ns) until @@Az sets it; aligned to UTC, not GPS
  time.  Saved to the module's BBR and flash.
- **Antenna supervisor:** UBX-CFG-ANT with short detection, power-down
  on short and recovery all on, saved.  TIM 1.1x ships with them off
  (protocol spec Appendix C.1), and R1 only limits a short's current
  until the module cuts V_ANT.
- **USART1** on TSSOP20 pins 16/17 needs the SYSCFG PA11/PA12 remap
  to PA9/PA10.
- **RESET_N** (PA4) is driven open-drain only: u-blox says never drive
  it high.
- **Bootloader re-entry:** the factory NBOOT_SEL = 1 ignores BOOT0,
  so once the part is programmed JP2 does nothing.  The firmware
  either clears NBOOT_SEL or offers a jump to the ROM bootloader, or
  updates over J5 stop working.  After the first flash the EMPTY
  flag needs a power cycle or option-byte reload (AN5673).  The
  STM32C091's ROM bootloader also listens on USART2, the module's
  link (AN2606, STM32C091xx/92xx), and takes the first interface to
  send it 0x7F, so the jump holds the module in reset (RESET_N low)
  first; a blank or bootloader-mode part with the module running may
  answer only over SWD.
- **PA15** shares TSSOP20 pin 19 with PA14-BOOT0/SWCLK on the STM32C091
  and is never driven.
- **RAM:** UBX messages such as NAV-SAT (8 + 12 bytes per satellite)
  and RXM-RAWX (16 + 32) are parsed as they stream in.

## Firmware

Rust, on Embassy, in `firmware/`: a workspace of the crates that build
on a host (`oncore-core`, `oncore-app`, `oncore-host`; one `cargo test`
runs them all, with shared lints and one `rustfmt.toml`), and
`oncore-fw`, outside it, which builds for the STM32.  It targets the Z3801A (3543) and
Z3805A (3543B) first, whose message tables are the same apart from
addresses, then the 58503A (3633, 3704).  No board exists yet; the code
is written and tested on the host.

The emulator presents one Oncore model, chosen at build time, its
personality.  The VP reference's model numbers (p. 2) and the engines
on the bench (smartclockmon `docs/firmware/gps.md`) give two:

| Model | What it is | Software | Seen in |
|---|---|---|---|
| B1121P1114 | 6-channel VP (B1) | 8.4, options IB | Z3801A, Z3805A |
| B4121P1115 | 8-channel VP (B4) | 8.8, options IB | 58503A |

The Z380x images speak only the six-channel messages.  The 58503A
images take either and switch to the eight-channel ones once the
engine sends `@@Ea`.  The model sets the `@@Cj` identity and the
channel count, and so which messages it answers.  `oncore-fw` takes it
as a feature, `b1121p1114` (the default) or `b4121p1115`, and refuses
to build with both or neither.  How the images talk to the engine is
smartclockmon's `docs/firmware/gps.md`; the messages and what the images
settle are in `docs/oncore-messages.md`.

Settings the instrument sends (the `@@A` messages):

- **Mapped to the module:** time and date (as aiding before the first
  fix), initial position and height, mask angle, application type
  (dynamic model), position hold, altitude hold, UTC or GPS time, 1 PPS
  offset and cable delay, through UBX-CFG-NAV5, CFG-TMODE2 and CFG-TP5.
  The GMT offset is applied by the emulator.
- **Channel selection:** the emulator has the Oncore's 6 (or 8)
  channels and fills them from the satellites the module tracks by the
  Oncore's rules: `Ah`/`Ai` (automatic, manual, highest in sky), `Aj`
  (xDOP type), `Ak` (hysteresis), `Ar` (Best-4 or all in view),
  `Al`/`AC` (xDOP thresholds) and `Am` (ignore list).  The per-channel
  messages and Time RAIM work on the channel set; the module still
  navigates on every satellite it tracks, ignored ones included.
- **No module equivalent:** `Aq` (ionosphere model), `An` (almanac
  update), `AD` (smoothing thresholds) and `Ax` (measurement epoch
  offset) are stored and answered and change nothing.  The images set
  each to what the module does anyway.
- **Datum:** WGS-84 only.  Any `Ao` is answered as datum 49 with
  WGS-84's parameters (in `@@Ap`, as the images take it); `Ap` is not
  implemented.  Every image selects 49, and none decodes the `Ap`
  answer.

Satellite reports (`@@Ba`, `@@Bb` and their eight-channel forms):

- **Tracking mode**, from the module's quality indicator and whether it
  holds the ephemeris: searching 0, acquired 1, detected but unusable
  2, code locked without ephemeris 7, locked with ephemeris 8.  Mode 8
  alone puts a satellite in the images' position set; 1 to 4, 5 to 6
  and 7 to 8 are the status screen's bands (smartclockmon, from the
  images' C).
- **Signal strength** is the Oncore's 0 to 255 "proportional to SNR",
  which the images print raw, without units.  It is proportional to
  amplitude, C/N0 = 20 log10(SS) + K, and the emulator takes K = 3
  dB-Hz for both models, a healthy engine's, within about 2:
  - The exponent: fitted 2.09 (0.23 dB RMS) for the bench 58503A's
    B4121P1115 and 1.98 for the Z3805A's B1121P1114, from the bench's
    2026-10-03 logs (the u-blox's C/N0 bands against each engine's SS
    at the same quantiles, same antenna and day), with slope 1.05
    between the two over 4105 same-minute pairs.  So one scale.
  - The offset: an engine stops tracking at a fixed SS, about 20 on
    both bench units.  Motorola puts the VP's tracking threshold at
    -143 dBm (VP Oncore engineering notes), about 29 dB-Hz with a noise
    figure of 1.5 to 2.5 dB (assumed).  So K = 29 - 20 log10(20), about
    3.  Full scale, 255, is then about 51 dB-Hz, about the strongest a
    good antenna gives.
  - The bench units against it: the 58503A measures K 3.5, healthy
    within error; the Z3805A measures 14.4, about 11 dB deaf, a fault
    in that unit, since its SS still stops near 20 (with an 11 dB
    different scale it would stop near 6).
  - The measured K includes the NEO-M8T's own C/N0 calibration, worth
    1 to 2 dB.
- **Doppler** (`@@Bb`): measured (RXM-RAWX) for tracked satellites,
  less the module's oscillator drift (NAV-CLOCK, 1.57542 Hz per ns/s at
  L1), since the Oncore's Doppler is the satellite's motion alone; for
  visible ones not tracked, computed from the almanac, as the Oncore
  computes it.  On apu-0's NEO-M8T the drift was -840 ns/s, about
  -1.3 kHz; over the trace the two agree within 2 Hz for all twelve
  tracked satellites, which fixes the correction's sign.
- **Navigation message** (`nav`, IS-GPS-200N): from the module's
  RXM-SFRBX, each GPS satellite's HOW alert and anti-spoof flags,
  subframe 1's URA index and health, the ephemeris and clock
  (subframes 1 to 3, once their issues of data agree), and the almanac
  (subframe 5 pages 1 to 24, subframe 4's for 25 to 32, and page 25's
  reference time), with position and velocity from Table 20-IV in `f64`
  (libm), one implementation for both.  `@@Ba`'s channel flags take alert,
  anti-spoof, unhealthy (module or subframe 1) and inaccurate (URA
  index 7 and up, a nominal URA over 16 m); parity errors never reach
  the emulator, since the module passes on only subframes whose parity
  holds.  `@@Bk`'s URAs are subframe 1's, 63 until decoded.

The protocol's source is the VP Oncore Command Reference
(`third_party/motorola/VPCommands.pdf`).  Where it is ambiguous,
smartclockmon's reading of the Z380x images settles it.  The emulator
must run with those images, so the tests check against them too.


- **`oncore-core`:** the translation, `no_std` with no allocation,
  tested on the host with `cargo test`.  So far: Oncore binary framing
  (frames are found by each ID's length, since data may hold `@` and
  CR) and UBX framing (a payload longer than the buffer is checked and
  reported, not kept).  `vp` has the two models and, for each, the
  lengths of the commands it takes and of its answers, from the
  reference, checked against the Z380x's and 58503A's tables.
  `engine` is the emulated Oncore's settings: each `@@A` command,
  `@@Cf` and `@@Cg`, with the reference's defaults and ranges.  A
  command with a field out of range is a query, answered with the
  current value.  The exception is `@@Az`, the cable delay: any value
  but the query form is taken and echoed exactly, signed, since the
  58503A adds its reference bias to it unclamped and resends it until
  it gets the echo.  Settings the module has counterparts for go out as
  module requests; the clock runs on its own until the module gives
  GPS time.  `module` turns each module request into UBX: CFG-NAV5
  (mask angle, dynamic model, altitude hold in MSL height), CFG-TMODE2
  (position hold, ellipsoid height), CFG-TP5 (the Oncore's 200 ms
  rising pulse, UTC or GPS grid, delays) and MGA-INI-POS_LLH (initial
  position).  Heights convert with the separation of the module's last
  fix.  `gnss` reads NAV-TIMEGPS (GPS time, leap seconds), NAV-PVT
  (fix, both heights, velocity), NAV-DOP, and, a record at a time,
  NAV-SAT and RXM-RAWX into `sky`, the GPS satellites by PRN
  (elevation, azimuth, C/N0, residual, quality, ephemeris, health,
  measured Doppler).  A message whose checksum fails changes nothing.
  `channels` fills the 6 or 8 channels: candidates are the GPS
  satellites with an orbit, healthy or of unknown health, at or above
  the mask angle and not ignored, the 12 highest.  Automatic selection
  evaluates every combination of 4 (Best-4) or of the channel count
  (all in view) by the `@@Aj` xDOP, in `f32` with a sine table, keeps
  the nine best for `@@Bc`, and changes the satellites giving position
  only when the best beats them by more than the `@@Ak` hysteresis.
  The search runs in steps so the firmware can serve its UARTs between
  them (924 combinations for 6 of 12).  `reports` builds `@@Ba` from
  the engine: local time of the measurement epoch (the nearest second,
  as the module labels the epoch; the fraction is NAV-PVT's `nano` when
  the epoch is after the second and 0 when before, since the module's
  free-running clock carries its epoch across the second and the
  seconds must run on one a second, as an Oncore's do), the fix, velocity,
  the xDOP of the satellites giving position (0 in position hold),
  visible and tracked counts, the channels and the receiver status.
  The engine sends it polled or every 1 to 255 s on the GPS second
  (`tick`), and in idle mode answers a poll with the last one sent
  while fixing (p. 70).  The channel flags for momentum alert,
  anti-spoof and accuracy come from the satellites' subframes (`nav`,
  below).  `@@Cj` is each model's identity in the
  layout the 58503A's B4121P1115 sends (smartclockmon
  `crates/smartclockd/src/journal.rs`): the copyright line, then nine
  label lines padded to 26 characters, options `IB`; the serial number
  and manufacture date are the emulator's own: `EMU` and seven digits
  from the STM32's unique ID, and the firmware's build date as the
  engines give it (year digit, month A to L, day; `build.rs`,
  `SOURCE_DATE_EPOCH` for a reproducible build).  PRN 32 is reported
  like any other, as a real engine does; only the 58503A's tracking
  event log, which packs a satellite in 5 bits, cannot tell it from
  PRN 10.  `@@Bj` is the coming
  leap second from NAV-TIMELS.  `@@Ca` and `@@Fa` pass the Oncore's
  hardware tests and fail every channel correlation test once the
  module has been silent 3 s.  `@@Bb` lists the visible satellites,
  at most 12, the highest first, with Doppler, elevation, azimuth and
  health (removed by `@@Am` or not); `@@Bc` the selection's best
  combinations; `@@Bd` the almanac's status, its week, toa and
  satellites, the EEPROM almanac the RAM's, as a real engine's is once
  copied (p. 78), though the emulator keeps none;
  each polled or sent on each change.  `@@Bk` gives the
  DOPs (each 0 outside its fix modes), NED velocity, ECEF position
  (NAV-POSECEF), the least-squares inverse normal matrix of the
  satellites giving position (east, north, up, time) and clock bias
  and drift (NAV-CLOCK; the drift's magnitude, the field being
  unsigned), polled or every 1 to 255 s.  Its magnetic
  variation is the World Magnetic Model 2025's declination at the fix
  and UTC date (`wmm`; the reference's engine used WMM-95), from NOAA's
  coefficient file, which `oncore-core`'s `build.rs` turns into a
  table; it matches all of NOAA's test values, declination to 0.01
  degree and the field to 0.01 nT.  The B4121P1115 also answers
  `@@Ea` and `@@Ek`, the same layouts with eight channels and eight
  URAs.  It sends `@@Ea` only when asked, as an engine does, so a
  58503A learns of eight channels as it would with its own engine
  (smartclockmon `gps.md`, "Six or eight channels").
- **Time RAIM** (`traim`, VP reference pp. 102-106): each channel
  satellite giving position, mode 8 and used by the module, measures
  the receiver's time offset by its NAV-SAT pseudorange residual, in
  ns; the solution is their mean, and its one-sigma estimate their
  standard deviation over the root of their count (the reference says
  only that it comes from the residuals' spread).  The reference's
  table gives the satellites the alarm limit needs to detect and to
  isolate a fault; isolation also needs position hold (p. 54).  The
  satellite that disagrees most with the solution of the others is a
  fault when it disagrees by more than the alarm limit: isolated and
  removed when possible, else the solution is in ALARM.  UNKNOWN when
  Time RAIM is off, the limit is under 250 ns, or the satellites are
  too few.  An isolated satellite leaves this solution and its report,
  not the module's, which navigates on every satellite.  `@@Bn` (and
  `@@En`) carry the settings, the 1 PPS rate (1) and the time of the
  next pulse, pulse status and time base, both statuses, the
  estimate, the negative sawtooth (TIM-TP's qErr, negated, in ns) and
  each channel's satellite with its estimate of the fraction of the
  second.  The 1 PPS control mode goes to CFG-TP5: off; on; on only
  once the module has GNSS time (for "while tracking at least one
  satellite"); or on only while the solution is OK, switched as the
  status changes.
- **Pseudorange corrections** (`differential`, VP reference pp. 88-89):
  `@@Bh` asks for them, polled or every 1 to 255 s, and the engine
  answers with `@@Ce`, the last whole set of corrections, a second old,
  with its own measurement time; the engine computes them a satellite a
  step between I/O, as it selects channels.  Each holds the measurement
  time and, for each channel's
  satellite, the range from the module's position (NAV-POSECEF, the
  held position in position hold) to the satellite, from its ephemeris
  at transmission and turned by the earth's rotation in transit, less
  the RXM-RAWX pseudorange with the satellite's clock (polynomial,
  relativistic term, L1 group delay) taken out; the same for the range
  rate against the Doppler; and the ephemeris' IODE.  The measurement
  time is NAV-CLOCK's epoch less its bias; rcvTow is 15 ms earlier on
  TIM 1.10.  The receiver's clock comes out of the pseudoranges as
  rcvTow less that time, to the whole millisecond the corrections'
  mean puts it at (the module steps its clock in milliseconds), and
  out of the rates as their mean (NAV-CLOCK gives the drift only to the
  ns/s, 0.3 m/s).  What remains is the atmosphere's delay and the
  broadcast orbit's and clock's errors.  Over the trace, every
  correction is between -60 and +10 m, the most negative low in the
  sky; at its last epoch twelve fit a bias and an elevation mapping
  within 1.4 m rms; 98% of the rates are within 0.16 m/s of zero.  The
  B4121P1115 sends a second `@@Ce` for channels 7 and 8 when they have
  corrections (p. 88).  The images show the corrections' mean and
  standard deviation on a diagnostic page (smartclockmon
  `structures.md`).
- **Module set-up** (`module::setup`, a message a step): UART1 to
  115200 baud, UBX only; the time pulse; each message the engine reads
  once a second (NAV-TIMEGPS, PVT, DOP, SAT, TIMELS, POSECEF, CLOCK,
  RXM-RAWX, MON-HW, TIM-TP); the antenna supervisor (CFG-ANT: supply
  control, short detection, power down on a short, recovery); then a
  save to battery-backed RAM and flash.  The time pulse is the VP's
  (engineering notes p. 7): 1 Hz, the time mark on the rising edge,
  200 ms high, through U3, which does not invert.  Open-circuit
  detection is off and not planned: it needs a sense circuit across
  R_BIAS driving EXTINT1 (ANT_DET_N; integration manual 2.4.4, Figure
  13), which the board does not have.  MON-HW gives the engine the antenna
  state, TIM-TP the next pulse's quantization error.  The VP has no
  antenna status message.
- UBX is encoded and decoded by hand from the receiver description,
  not with the `ublox` crate (0.10): its all-messages decoder costs
  3.1 KB of flash, it maps positions to `f64`, which is soft float on
  the M0+, its CFG-TMODE2 scales latitude by 1e-5 where the receiver
  description gives 1e-7, and it has no CFG-CFG.  Test cases come from the Command Reference and
  the message tables in smartclockmon `docs/firmware/oncore/`;
  smartclockmon's simulator speaks SCPI, not Oncore.
- **`oncore-app`:** the emulator running, `no_std` on
  `embedded_io_async` ports and `embassy_time`, the same on the STM32
  and on a host.  `run` finds the module at 115200 baud (its saved
  set-up) or moves it from 9600, sends the set-up a message at a time
  waiting for each ACK (three tries), and gives the engine's settings
  to the module.  Then one task serves both ports: the module's
  messages feed the engine, NAV-EOE ends each epoch and runs the
  engine's second, the instrument's commands are answered, channel
  selection starts every 5 epochs and runs 8 combinations at a time
  when no byte is waiting, and a 1.5 s timer runs the engine's second
  if the module falls silent.  Answers and module requests are
  gathered, then written.  Its test runs it between a fake module and
  a fake instrument.  With the module silent the engine's second runs
  each second, after 1.5 s without an epoch.
- **Test data:** `firmware/testdata/apu0-2026-10-28.ubx`, fifteen
  minutes of a NEO-M8T-0 (TIM 1.10, as the board's module) with every
  message the engine reads and the GPS subframes (its README).
  `oncore-core`'s `tests/trace.rs` runs it through the engine and
  checks each epoch's `@@Ba` and `@@Bn`; `oncore-host --module file:`
  replays it.
- **`oncore-host`:** `run` on a PC (tokio): `--module serial:PATH` (set
  up as on the board), `file:PATH` (a raw UBX recording such as
  `gpspipe -R` writes, played an epoch a second) or `gpsd:HOST:PORT`
  (a gpsd device's raw stream, listened to only); `--oncore PATH`, a
  serial port at 9600 such as a USB adapter on J1 or a pty; `--model`.
  A recording or a gpsd device is not configured, so it must already
  carry the messages the engine reads.  Events go to stderr.
- **`oncore-fw`:** the STM32C091FC binary (`thumbv6m-none-eabi`, set in
  its `.cargo/config.toml`): USART2 (PA2/PA3) to the module and USART1
  (PA9/PA10, remapped onto pins 16/17) to J1, both starting at 9600 8N1,
  under `oncore_app::run`; events go out over defmt RTT.  The module's
  receive buffer is 2 KB, a second's messages at 115200, and the
  instrument's transmit buffer 1 KB, so a long answer at 9600 does not
  hold up the module.  STATUS (PA5) toggles on each 1 PPS edge (PA0).
  RESET_N (PA4) is open drain, released.
- Build with `cargo build --release` in `oncore-fw`; `cargo run
  --release` flashes over SWD with probe-rs.  The release profile
  optimizes for size.  The default features are the B1121P1114 and
  `rtt`, events and panics over RTT (defmt) for a debug probe; the
  production build leaves `rtt` out, logs nothing and halts on a panic:
  `cargo build --release --no-default-features -F b1121p1114` (or
  `b4121p1115`).  The STM32C091FC has 256 KB of flash and 36 KB
  of RAM; with the navigation message, orbits, magnetic model and
  pseudorange corrections the production build measures 70.6 KB of
  flash and 13.4 KB of static RAM, the `rtt` build 86.0 KB and 13.7 KB,
  where the STM32C011F6 it replaced has 32 KB and 6 KB.  The
  ephemerides' subframes are 3.1 KB of that RAM.

## Choosing the module

Datasheets are in `third_party/u-blox/`.  Prices were checked
2026-10-12 against distributor pages and move; "checked" means seen
on a distributor or u-blox document that day, "unchecked" means taken
from a secondary write-up and not confirmed.

### u-blox

| Part | Bands | 1σ time pulse | Status | Price (single unit) |
|---|---|---|---|---|
| ZED-F9T-20B | L1 + L2 or L5 (one pair at a time), GPS/GAL/BDS | 5 ns absolute, 2.5 ns differential, jitter ±4 ns | Mass production, datasheet R04 2026-05-28 | Digi-Key EU about €172 (checked); a $199 USD listing was a test storefront with no stock; US price not confirmed |
| LEA-F9T-10B / -20B | L1/L2 or L1/L5 | about 5 ns (unchecked) | Active | Digi-Key US $259, about 1,900 in stock (checked); EU about €235 |
| LEA-F9T-11B / -21B | as above | not checked | New at Mouser and Digi-Key | about €233-242 at Mouser (checked); how they differ from -10B/-20B not found |
| NEO-F10T-00B | L1 + L5 (GPS, GAL, BDS, NavIC) | 10 ns; 5 ns with jitter removed; jitter ±8 ns; 16 ns resolution | Mass production, datasheet R06 2026-04-28 | $160 (checked on aggregators; Digi-Key page says discontinued at Digi-Key) |
| ZED-F9T-00B / -10B | L1/L2 or L1/L5 | 5 ns | -10B marked NRND at Mouser; -20B replaces both | not checked |
| NEO/LEA-M8T | L1 only | under 20 ns | u-blox's series page says no longer available; distributors still stock LEA-M8T-0 and no EOL notice found | $96.15 at Digi-Key (reported by the maintainer, not seen by me) |

Corrections to what was first written up:

- The F9T-20B's band choice is L1+L2 or L1+L5, configured at run
  time, not all three at once (datasheet footnote 11).  No GLONASS
  appears in its acquisition table.
- It is rated -40 to +85 °C.  The +105 °C rating belongs to the
  LEA-F9T-10B, not the ZED.
- The 10 ns NEO-F10T figure is confirmed in the R06 datasheet; it is
  roughly twice the F9T's.  It has one UART and no USB.
- GLONASS and L5 on the F10T, and Galileo OSNMA on the F9T-20B: not
  found in the datasheet text read, so not asserted.
- The 5 ns is absolute only after entering the antenna, cable and
  front-end delay.  Uncalibrated, expect tens of ns of bias.
- None of these parts takes an external reference oscillator.  The
  1 PPS sits on the internal TCXO grid, so the TIM-TP qErr
  (sawtooth) correction is what the translator carries into the
  Oncore sawtooth field.

### Not u-blox (unchecked unless noted)

- **Septentrio mosaic-T:** takes an external 10 MHz reference, so the
  sawtooth problem goes away; 5 ns, event input under 20 ns;
  500 mA module maximum (checked).  SparkFun $849.95, $722-807 in
  volume (checked); GNSS Store price not checked.
- **Trimble/Protempis RES 720:** L1/L5, under 5 ns, TSIP; price on
  request.
- **Furuno GT-100 / GT-9001:** headline 4.5 ns is stability, absolute
  is about ±40 ns; good multipath rejection.
- **Quectel LC99T / LC29T:** 13.6 ns 1σ; cheap.
- **SkyTraq PX1120T:** L1 only, 5 ns claimed from a preliminary
  datasheet.

An L1/L5 patch antenna such as the ANN-MB1 cannot serve the L2
configuration; choose the band plan first, then the antenna.

## Open questions

Numbered as cited elsewhere (the schematic's notes, `docs/`).

3. The Oncore socket's connector, pinout, supply and 1 PPS level and
   polarity, against the VP and UT+ engineering notes
   (`third_party/motorola/`).  Synergy (TN 484-D, TN 502-C) gives the
   VP, UT+ and GT+ one pinout and labels pin 8 TTL TxD, but describes
   it as "Receiver Command Input", against Motorola's "primary output"
   (UT+ notes); the UT+ notes' idle levels (pin 8 high, pin 9 low) fit
   Motorola's, and the board is wired that way.  Measure the
   instrument's idle levels to confirm it.

A bug in the emulator shows in every log afterwards as oscillator
behavior, so the first test is one receiver, one antenna, its week of
MDEV and ADEV before and after.
