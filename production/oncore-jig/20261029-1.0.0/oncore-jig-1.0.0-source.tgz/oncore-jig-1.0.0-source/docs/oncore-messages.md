# Oncore messages the emulator implements

The messages a VP Oncore in a Z3801A (3543), Z3805A (3543B) or 58503A
(3633, 3704) is sent, and what each needs from the engine.  Formats
are the VP Oncore Command Reference's
(`third_party/motorola/VPCommands.pdf`).  How the images frame, match
and time out messages, and what they do with Time RAIM, is in
smartclockmon's `docs/firmware/gps.md` on its `main`, the single account
of how these images talk to their Oncore: "Emulating the engine" and
"Channel mode and signal strength" above all.  That account, read from the images' C and
ROMs, settles what the reference leaves ambiguous; the points it
settles are listed below.

## Models

| Model | Channels | Software | Instruments |
|---|---|---|---|
| B1121P1114 | 6 | 8.4, options IB | Z3801A, Z3805A |
| B4121P1115 | 8 | 8.8, options IB | 58503A |

The build chooses one (`oncore-fw` features `b1121p1114`,
`b4121p1115`).  The 58503A switches to eight-channel messages once an
`@@Ea` arrives; the Z380x are six-channel only.  Software 8.8 keeps the
58503A from sending its second `@@Ar` (argument 65, undefined in the
reference), which goes only to 8.4.

## The messages

Lengths are whole messages, `@@` to LF.  "Rate" is the reference's
output rate byte: 0 sends the message once, 1 to 255 every that many
seconds.

| ID | What | Command | Answer | Models |
|---|---|---|---|---|
| `Aa` | time of day | 10 | `Aa`, 10 | both |
| `Ab` | GMT offset | 10 | `Ab`, 10 | both |
| `Ac` | date | 11 | `Ac`, 11 | both |
| `Ad`, `Ae` | latitude, longitude | 11 | the same, 11 | both |
| `Af` | height | 12 | `Af`, 15 (GPS and MSL heights) | both |
| `Ag` | mask angle | 8 | `Ag`, 8 | both |
| `Ah` | satellite select | 8 | `Ah`, 8 | both |
| `Ai` | manual satellite select | 9 | `Ai`, 9 | both |
| `Aj` | xDOP type | 8 | `Aj`, 8 | both |
| `Ak`, `Al` | xDOP hysteresis, 3-D to 2-D threshold | 9 | the same, 9 | both |
| `Am` | satellite ignore list | 12 | `Am`, 12 | both |
| `An` | almanac update | 8 | `An`, 8 | both |
| `Ao` | datum | 8 | **`Ap`**, 25 | both |
| `Aq` | ionospheric correction | 8 | `Aq`, 8 | both |
| `Ar` | position fix algorithm | 8 | `Ar`, 8 | both |
| `As` | position-hold position | 20 | `As`, 20 | both |
| `At` | position hold on/off | 8 | `At`, 8 | both |
| `Au` | altitude-hold height | 12 | `Au`, 12 | both (58503A sends it) |
| `Av` | altitude hold | 8 | `Av`, 8 | both |
| `Aw` | UTC or GPS time | 8 | `Aw`, 8 | both |
| `Ax` | measurement epoch offset | 9 | `Ax`, 9 | both |
| `Ay`, `Az` | 1 PPS offset, cable delay | 11 | the same, 11 | both |
| `AB` | application type | 8 | `AB`, 8 | both |
| `AC` | 2-D to 0-D HDOP threshold | 9 | `AC`, 9 | both |
| `AD` | correction thresholds | 9 | `AD`, 9 | both |
| `Ba` | 6-channel position, status, data | 8, rate | `Ba`, 68 | both |
| `Bb` | visibility | 8, mode | `Bb`, 92 | both |
| `Bc` | 6-channel xDOP table | 8, mode | `Bc`, 82 | both |
| `Bd` | almanac status | 8, mode | `Bd`, 23 | both |
| `Bh` | pseudorange correction output | 8, rate | **`Ce`**, 52; a second for channels 7 and 8 | both |
| `Bj` | leap second pending | 8 | `Bj`, 8 | both |
| `Bk` | 6-channel position extension | 8, rate | `Bk`, 69 | both |
| `Bn` | 6-channel Time RAIM | 22 | `Bn`, 59 | both |
| `Ca` | 6-channel self test | 7 | `Ca`, 9 | both |
| `Cf` | set to defaults | 7 | `Cf`, 7 | both |
| `Cg` | idle or position fix | 8 | `Cg`, 8 | both |
| `Ci` | switch I/O format | 8 | none | both |
| `Cj` | receiver ID | 7 | `Cj`, 294 | both |
| `Ea` | 8-channel position, status, data | 8, rate | `Ea`, 76 | B4121 |
| `Ek` | 8-channel position extension | 8, rate | `Ek`, 71 | B4121 |
| `En` | 8-channel Time RAIM | 22 | `En`, 69 | B4121 |
| `Fa` | 8-channel self test | 7 | `Fa`, 9 | B4121 |

`Bb`, `Bc` and `Bd` take a mode, not a rate: 0 sends the message once,
1 again whenever it changes.  `Bd`'s EEPROM almanac is the RAM's, as a
real engine's is once its background copy is done (p. 78); the
emulator keeps no almanac in nonvolatile memory.  No image reads
`Bd`'s record: only its decoder touches it, and nothing but the
console asks for it (smartclockmon, the hand-written C and a ROM scan
of all four images).
`Bh`'s corrections are a reference station's, against the module's
position (PLAN.md, "Pseudorange corrections").  `Bd` and `Bh` are in
every image's table, sent only from the console.

## What the images settle

- **`@@Ao` is answered by `@@Ap`**, where the reference gives `@@Ao`.
  The images take only `@@Ap`, and have no length for `@@Ao`.
- **`@@Bh` is answered by `@@Ce`**, as the reference gives; the images
  frame `@@Ce`, 52 bytes, and have no length for `@@Bh`.
- **Never send `@@Ao`, `@@Bh` or `@@Ci`.**  Their table length is 0,
  and the framer would run on for about 65530 bytes.
- **`@@Cg` is 8 bytes**, with its mode byte; the reference says 7.
- **`@@Ci` 0**, the Z380x's first command, is a format the reference
  does not define.  The engine stays in binary and does not answer.
- **Echoes are byte for byte**, checksum included, with the exceptions
  for `Ab`, `Af`, `As` and `Cg` in `gps.md`, "Answer matching".
- **`@@Cj`:** each line starts with its label, and `OPTIONS LIST`
  holds `I`, or the images send no Time RAIM.
