# oncore-emulator

Rev 1.0.0, not yet built: a modern u-blox timing receiver behind a
small microcontroller that speaks the Motorola Oncore binary protocol,
as a drop-in replacement for the GPS engine inside HP / Symmetricom
SmartClock receivers (58503A, Z3801A, Z3805A and kin) that take the
Oncore with a right-angle antenna jack.  Hosts that plug a straight
jack into the motherboard (Z3816A, KS-24361) are not drop-in.

The firmware study these references point to is in
[smartclockmon](https://github.com/charlieh0tel/smartclockmon).

## Why

- **Sensitivity.**  Much greater than the Oncore's.  A current module
  with an amplified antenna may hold satellites where an Oncore on
  the same feed does not.
- **Rejection and selectivity.**  Possibly better against
  interference and out-of-band signals; not measured.
- **Channels.**  Many more than the Oncore's eight.  The firmware
  still sees only as many as its 8-channel messages carry.
- **Constellations.**  More than GPS alone, in some cases (see
  Choosing the module).
- **1 PPS quantization.**  Likely finer-grained.  The Oncore's 1 PPS
  carries a deterministic error from "the granularity of the clock
  generating the 1PPS signal", which the receiver reports as the
  negative sawtooth so a user can remove it (VP Oncore Command
  Reference, Time RAIM).  No SmartClock image applies it: the only
  reader of the field is the Time RAIM page (smartclockmon
  `docs/firmware/README.md`).  So all of it enters the measured
  interval, the white phase noise the stability curves show out to
  about 500 s on a 58503A (`docs/stability.md`).  Motorola gives the
  VP and UT+ under 50 ns 1σ in position hold; Synergy Systems gives
  its u-blox based replacement under 25 ns (tech note #484-D).
- **Availability.**  The Oncore engines are long out of production.
- **Week rollover.**  The engines predate the 1999 and 2019
  rollovers.  The emulator can present a week the firmware's own
  arithmetic turns into the right date, as Synergy's replacements
  do.

## Shape

- **GNSS:** a u-blox timing module (see Choosing the module).  None
  runs user code; the firmware is u-blox's.
- **Translator:** an STM32C0 (Cortex-M0+) with two USARTs: UBX from the
  module, Oncore binary to the instrument.
- **1 PPS:** the module's time pulse straight to the instrument's 1 PPS
  pin through a 3.3 V to 5 V level shifter.  The microcontroller never
  touches the edge, so it adds no jitter.
- **USB:** the module's own USB port brought out, for the full
  protocol (UBX, NMEA, raw measurements) to gpsd or u-center, and for
  module firmware updates, with no translator code.  VDD_USB comes
  from VBUS through its own 3.3 V regulator, enabled by the module's
  3.3 V supply, as u-blox requires: the module's D+ pull-up shows only
  to a powered host, and only while the module is powered.
- **Flashing the STM32:** SWD on a Tag-Connect TC2030, and the ROM
  serial bootloader for `stm32flash` on a 6-pin FTDI TTL-232R-3V3
  header (USART1, not fitted; 3.3 V only, since the bootloader turns
  on PA10's pull-up, which the STM32 forbids above 4 V), with BOOT0
  held high by a solder jumper.  The pin counts only once option bit
  NBOOT_SEL is 0; the factory setting ignores it, and a blank part
  boots the bootloader anyway (AN5673).  No USB on the STM32.  A
  blank or bootloader-mode STM32 in the instrument listens on J1 pin 9
  (USART1 RX): a 0x7F in the instrument's stream starts the
  bootloader, which answers on pin 8.
- **Power:** 5 V from the Oncore socket, regulated to 3.3 V.  On the
  bench, D8, a Schottky from VBUS, powers the board from USB-C; it
  can only feed an instrument from USB, never the other way.  Nothing
  but the USB host limits that current (D8 is rated 1 A): use a
  computer's port, not a charger, when the board is in an instrument
  that is switched off.  On USB alone +5V is VBUS less D8's drop, about
  4.4 to 4.7 V, under U3 and U6's 4.5 V minimum on a weak port, so J1's
  output levels are not guaranteed on the bench.
- **Antenna bias:** 5 V as the Oncore supplied it, or 3 V from the
  module's VCC_RF by a solder jumper, through u-blox's 10 ohm R_bias,
  27 nH and 10 nF (LEA-M8T hardware integration manual, Figure 12).
  Once the firmware has saved UBX-CFG-ANT (TIM 1.1x ships with short
  detection off), the module switches V_ANT off when it sees a short,
  retries, and reports the antenna's state in UBX-MON-HW, which the
  STM32 reads; R_bias limits the current until it does, about 0.5 A
  at 5 V, so it is a 0.25 W or better anti-surge part as u-blox's
  parts list asks.  A TPS2553 current limit
  was dropped: its range stops above the module's 100 mA absolute
  maximum, the -1 latches off, and its fault flag, with a 7.5 ms
  deglitch, would rarely see a short the module has already cut.
- **Board:** the Oncore's outline, 82.55 x 50.80 mm, with its four
  3.2 mm holes 3.0 mm from the edges, and within its height: the
  Oncore's parts reach 7.18 mm above the board (UT+ notes; VP 7.35
  max), this board's about 3.2 mm (J3).  Below, the Oncore has its
  shield S2 (6.9 mm) and J1 (8.2 mm); this board has only J1 and J2
  (6 mm body).  J1's heights are in `docs/oncore-ten-pin.md`.  The holes are plated, with 5.0 mm pads (the most the edge
  allows), and float, as the Oncore's do (checked on one).  J1 sits at the Oncore's position
  and takes a 2x5 header on either side: on the bottom to plug in as
  the Oncore did, or on top for a ribbon jumper down to the
  motherboard.  Seen from above, both ends of a straight-through IDC
  ribbon then mate the same way, so pin n meets pin n.  Pin 1 is
  marked on both sides, with the header's outline on top.  J1 is
  wired as Motorola's table has it: pin 8 (TXD1) is the receiver's
  output and pin 9 (RXD1) its input.  Synergy's description column
  has pin 8 the other way (open question 3).  R25 holds the transmit line at idle while the STM32 is in
  reset, halted or blank.  The antenna is a right-angle
  through-hole MCX jack on the bottom, as on the Oncore, with its pin
  at the Oncore jack's position and its face at the left edge; MCX
  mates with the OSX plug on the instrument's cable.  USB-C sits on
  the same edge below it, and the FTDI header on the lower edge,
  backed off so its pins stay inside the outline.  In the instrument
  the board is buried under the power supply, so both are for the
  bench.
- **Layers:** four, 1.6 mm, on JLCPCB's standard JLC04161H-7628
  stackup.  Layer 2 is unbroken ground under the module and the RF
  trace, which makes the 50 ohm J2 to RF_IN run 0.36 mm wide (0.2104
  mm of 7628 prepreg, Er 4.4, less a little for solder mask) instead
  of about 2.9 mm on two layers, and leaves routing easy around the
  module.
- **Ordering:** `hardware/release.py` builds the package in
  `production/YYYYMMDD-REV/` (see `.claude/skills/jlcpcb-release/`).
  JLC04161H-7628 with impedance control, since the RF
  trace's width assumes it; the board file records only the 1.6 mm
  thickness.  ENIG finish: the RF trace is bare copper.  J2 is the
  one through-hole part JLCPCB fits, on the bottom: confirm its
  bottom-side through-hole assembly when ordering.  JLCPCB has no model
  for J2: an order remark gives its face direction, off the left edge,
  as the bottom silk shows.  J2 and J3 overhang
  the left edge (x = 100): no rail or V-score on that edge.
- **Layout:** `hardware/schematic.py` drew the schematic and
  `hardware/board.py` made the outline, holes and placement from it.
  Both are retired: the schematic is edited and the board routed in
  KiCad, and schematic changes reach the board with Update PCB from
  Schematic.  TP2, a Keystone 5019 loop by J1 for a scope probe's
  ground clip, is not fitted.
- **Routing:** by hand in KiCad, every net connected.  Layer 2 is a
  GND plane and layer 3 a +3V3 plane, with GND pours on top and
  bottom; all four zones are drawn larger than the board and clipped
  by its outline.  GND and +3V3 pads reach their plane by a short
  N/S/E/W track to a via (two for pads 2.5 mm or longer), except U1's
  ground pins 13 and 14, which reach the top pour through its thermal
  spokes.  GND vias
  stitch the pours together 1 mm in from the edge every 3 mm (2 mm
  along the RF corner by J2, and on under J5's overhanging pins), and
  on a 5 mm grid inside, wherever both outer pours are solid copper
  and no part is in the way.  The RF trace is
  placed by hand and locked, keeps 3W (1.08 mm) to the pour and other
  nets, is fenced by ground vias along both sides, and has D7 on it
  beside J2.  It has no solder mask, except 0.4 mm dams either side of
  D7's pad and before U1 pin 16, so solder stays on those joints.  No other net's vias come within 0.4 mm of the module's
  pads.  Silkscreen text is 0.8 mm high with a 0.15 mm stroke.
- **Assembly:** JLCPCB, passives no smaller than 0603 except the RF
  input's ESD diode (PESD5V0F1BL, SOD-882: 0.4 pF, 5.5 V stand-off,
  above the 5 V antenna bias on RF_IN).  The schematic carries each
  part's manufacturer, part number and LCSC number, all in JLCPCB's
  stock on 2026-10-25 except J1 and the cell.  The LEA-M8T is JLCPCB's
  C2763452, a LEA-M8T-0 (TIM 1.10), of which JLCPCB had only 8: check
  the count before ordering.  JLCPCB places it with u-blox's T-shaped
  paste (integration manual Figure 6), so ask for the 150 um stencil.
  Why the -0 and not the -1 is in `docs/ublox-lea-m8t-version.md`.
  J4, JP1, JP2 and TP1 are footprints only, out of the BOM.  J1 is
  marked not fitted and the backup cell is not fitted: both are
  ordered loose and fitted by hand, J1 on whichever side the instrument
  needs.  J1 is a Samtec TSW-105-07-G-D (DigiKey), whose 5.84 mm mating
  length is the Oncore's; CJT's A2541WV-2x5P (LCSC C225520, 6.0 mm) is
  the LCSC alternative.  The connector's pinout, position and heights
  are in `docs/oncore-ten-pin.md`.  J5 and TP2 (the Keystone 5019, out
  of stock) are not fitted.  The STAT LED
  is yellow-green: a green's 3.1 V barely lights from 3.3 V.
- **Backup supply:** the module's V_BCKP tied to VCC by default.  The
  option not fitted is a Seiko MS621FE-FL11E rechargeable lithium cell
  (5.5 mAh, about 13 days at the module's 17 uA; rated -20 to +60 C,
  narrower than the module's -40 to +85 C), floated at about
  3.2 to 3.3 V through a BAT54J Schottky and 1k: at float current the
  Schottky drops only 0.1 to 0.15 V.  The cell wants 2.8 to 3.3 V,
  3.1 V recommended, so this is the top of its range; a silicon
  diode's 0.6 V would leave it at the bottom.  Its reverse leakage (2 uA maximum at 25 V,
  25 C) matters only while the board is unpowered, when the instrument
  has cooled and D3 sees about 3 V: a few percent of the module's
  backup current.  No SMD supercap comes close: the 0.22 F parts
  are end of life and the active ones hold minutes.  The
  cell is not reflowable (third_party/seiko/).  No known instrument
  drives the Oncore's BATT pin, so it is not used.

## What the translator does

- Answers, and sends, only the messages the target image expects.
  Nothing else goes on the wire, unsolicited or not.  smartclockmon
  `docs/firmware/oncore/models.md` lists them for the six Oncore
  images, and `<image>.txt` beside it gives each image's message
  table, request scripts and polling lists.
- Fills them from the module: time, satellites, position, receiver
  status; honors position hold, the survey, and cable delay; fills the
  T-RAIM fields.
- Presents a week number the firmware handles.
- Carries the module's own 1 PPS quantization error into the Oncore's
  sawtooth field.  The firmware displays it, which also shows whether
  anything applies it.

The firmware must also set the hardware up, since the module's and
the MCU's defaults are not the Oncore's:

- **1 PPS** goes from the module to J1 without passing through the
  MCU, so its shape is the module's.  UBX-CFG-TP5 sets it to the
  Oncore's: a 200 ms (+/-1 ms) rising-edge pulse from power-up, not
  the TIM default of 100 ms only once locked; antenna cable delay 0
  (the default is 50 ns) until @@Az sets it; aligned to UTC, not GPS
  time.  Saved to the module's BBR and flash.
- **Antenna supervisor:** UBX-CFG-ANT with short detection, power-down
  on short and recovery all on, saved.  TIM 1.1x ships with them off
  (protocol spec Appendix C.1), and R1 only limits a short's current
  until the module cuts V_ANT.
- **USART1** on TSSOP20 pins 16/17 needs the SYSCFG PA11/PA12 remap
  to PA9/PA10.
- **RESET_N** (PA4) is driven open-drain only: u-blox says never drive
  it high.
- **Bootloader re-entry:** the factory NBOOT_SEL = 1 ignores BOOT0,
  so once the part is programmed JP2 does nothing.  The firmware
  either clears NBOOT_SEL or offers a jump to the ROM bootloader, or
  updates over J5 stop working.  After the first flash the EMPTY
  flag needs a power cycle or option-byte reload (AN5673).
- **RAM:** the STM32C011 has 6 KB, so UBX messages such as NAV-SAT
  (8 + 12 bytes per satellite) are parsed as they stream in, or the
  constellations limited.

The translation as a `no_std` crate, tested on a host against
smartclockmon's simulator and the firmware's message tables before any
board exists, with a thin STM32 binary over it.

## Choosing the module

Datasheets are in `third_party/u-blox/`.  Prices were checked
2026-10-12 against distributor pages and move; "checked" means seen
on a distributor or u-blox document that day, "unchecked" means taken
from a secondary write-up and not confirmed.

### u-blox

| Part | Bands | 1σ time pulse | Status | Price (single unit) |
|---|---|---|---|---|
| ZED-F9T-20B | L1 + L2 or L5 (one pair at a time), GPS/GAL/BDS | 5 ns absolute, 2.5 ns differential, jitter ±4 ns | Mass production, datasheet R04 2026-05-28 | Digi-Key EU about €172 (checked); a $199 USD listing was a test storefront with no stock; US price not confirmed |
| LEA-F9T-10B / -20B | L1/L2 or L1/L5 | about 5 ns (unchecked) | Active | Digi-Key US $259, about 1,900 in stock (checked); EU about €235 |
| LEA-F9T-11B / -21B | as above | not checked | New at Mouser and Digi-Key | about €233-242 at Mouser (checked); how they differ from -10B/-20B not found |
| NEO-F10T-00B | L1 + L5 (GPS, GAL, BDS, NavIC) | 10 ns; 5 ns with jitter removed; jitter ±8 ns; 16 ns resolution | Mass production, datasheet R06 2026-04-28 | $160 (checked on aggregators; Digi-Key page says discontinued at Digi-Key) |
| ZED-F9T-00B / -10B | L1/L2 or L1/L5 | 5 ns | -10B marked NRND at Mouser; -20B replaces both | not checked |
| NEO/LEA-M8T | L1 only | under 20 ns | u-blox's series page says no longer available; distributors still stock LEA-M8T-0 and no EOL notice found | $96.15 at Digi-Key (reported by the maintainer, not seen by me) |

Corrections to what was first written up:

- The F9T-20B's band choice is L1+L2 or L1+L5, configured at run
  time, not all three at once (datasheet footnote 11).  No GLONASS
  appears in its acquisition table.
- It is rated -40 to +85 °C.  The +105 °C rating belongs to the
  LEA-F9T-10B, not the ZED.
- The 10 ns NEO-F10T figure is confirmed in the R06 datasheet; it is
  roughly twice the F9T's.  It has one UART and no USB.
- GLONASS and L5 on the F10T, and Galileo OSNMA on the F9T-20B: not
  found in the datasheet text read, so not asserted.
- The 5 ns is absolute only after entering the antenna, cable and
  front-end delay.  Uncalibrated, expect tens of ns of bias.
- None of these parts takes an external reference oscillator.  The
  1 PPS sits on the internal TCXO grid, so the TIM-TP qErr
  (sawtooth) correction is what the translator carries into the
  Oncore sawtooth field.

### Not u-blox (unchecked unless noted)

- **Septentrio mosaic-T:** takes an external 10 MHz reference, so the
  sawtooth problem goes away; 5 ns, event input under 20 ns;
  500 mA module maximum (checked).  SparkFun $849.95, $722-807 in
  volume (checked); GNSS Store price not checked.
- **Trimble/Protempis RES 720:** L1/L5, under 5 ns, TSIP; price on
  request.
- **Furuno GT-100 / GT-9001:** headline 4.5 ns is stability, absolute
  is about ±40 ns; good multipath rejection.
- **Quectel LC99T / LC29T:** 13.6 ns 1σ; cheap.
- **SkyTraq PX1120T:** L1 only, 5 ns claimed from a preliminary
  datasheet.

An L1/L5 patch antenna such as the ANN-MB1 cannot serve the L2
configuration; choose the band plan first, then the antenna.

## Open questions

1. Fields the firmware reads that were not traced: T-RAIM status, the
   survey and position-hold handshakes, cable delay.
2. The firmware's rollover arithmetic, and so the week to present.
3. The Oncore socket's connector, pinout, supply and 1 PPS level and
   polarity, against the VP and UT+ engineering notes
   (`third_party/motorola/`).  Synergy (TN 484-D, TN 502-C) gives the
   VP, UT+ and GT+ one pinout and labels pin 8 TTL TxD, but describes
   it as "Receiver Command Input", against Motorola's "primary output"
   (UT+ notes); the UT+ notes' idle levels (pin 8 high, pin 9 low) fit
   Motorola's, and the board is wired that way.  Measure the
   instrument's idle levels to confirm it.
4. Antenna current: the LEA-M8T specifies V_ANT for under 50 mA,
   while the UT+ notes allow an Oncore antenna 15 to 80 mA.  Measure
   the instrument's antenna.  Whether any firmware image reads an
   antenna fault from the Oncore status messages, so the module's
   UBX-MON-HW antenna state can be reported, is not traced.
5. USB: ground between host and instrument (isolation), and the
   cable's way out of the chassis.
6. Which module: see Choosing the module.  No decision criteria yet.

A bug in the emulator shows in every log afterwards as oscillator
behavior, so the first test is one receiver, one antenna, its week of
MDEV and ADEV before and after.
